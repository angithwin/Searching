-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2020 at 05:58 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `quote`
--

CREATE TABLE `quote` (
  `quote_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `quote` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `short_msg` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `long_msg` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `trans_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quote`
--

INSERT INTO `quote` (`quote_id`, `quote`, `short_msg`, `long_msg`, `trans_date`) VALUES
('1', 'no pain no gain', 'Nothing will come of nothing.', 'All of us should take efforts to get the results that we want. Otherwise, the future will be bleak. For the betterment of humanity, we have to do many good acts which will produce the expected results. The humankind has seen many such people who have left behind their foot prints of many achievements which produce the same results.', '2020-07-30 12:09:00'),
('2', 'dry up while sun is shinning', 'Make good use of your time or make the most of an opportunity while you have the chance.', 'Opportunities may only come along every so often. It is good to take stock of a situation and realize when an opportunity presents itself. If you can act on it before it slips away', '2020-07-31 00:16:39'),
('3', 'Business opportunities are like buses, there is always another one coming.', 'Richard Branson', '', '2020-08-10 13:35:29'),
('4', 'Starting your own business is not just a job. It is a way of life.', 'Richard Branson', '', '2020-08-10 13:35:29');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
